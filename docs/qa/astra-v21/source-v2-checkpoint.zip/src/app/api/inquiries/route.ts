import { NextRequest, NextResponse } from "next/server";
import { validateInquiry } from "@/lib/validation/inquiry";
import {
  calculateFrontendEstimate,
  getPackageById,
  PRICING_ADDONS,
} from "@/lib/pricing/calculator";
export async function POST(req: NextRequest) {
  try {
    // Bound the stream itself; Content-Length alone is not a trusted size limit.
    const reader = req.body?.getReader();
    if (!reader)
      return NextResponse.json(
        { success: false, error: "Empty request." },
        { status: 400 },
      );
    const chunks: Uint8Array[] = [];
    let bytes = 0;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 16384) {
        await reader.cancel();
        return NextResponse.json(
          { success: false, error: "Request too large." },
          { status: 413 },
        );
      }
      chunks.push(value);
    }
    let body: unknown;
    try {
      body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
      return NextResponse.json(
        { success: false, error: "Invalid JSON." },
        { status: 400 },
      );
    }
    const validation = validateInquiry(body);
    if (!validation.success)
      return NextResponse.json(
        {
          success: false,
          error: "Please check your inquiry details.",
          issues: validation.error.flatten(),
        },
        { status: 400 },
      );
    const data = validation.data;
    const pkg = data.packageId ? getPackageById(data.packageId) : undefined;
    if (data.packageId && !pkg)
      return NextResponse.json(
        { success: false, error: "Invalid package." },
        { status: 400 },
      );
    const addons = Array.from(new Set(data.addons || [])).filter((id) =>
      PRICING_ADDONS.some((a) => a.id === id),
    );
    const quote = pkg ? calculateFrontendEstimate(pkg.id, addons) : undefined;
    const context = [
      pkg ? pkg.name.ms + " — RM" + quote!.total : "",
      pkg && !pkg.isFullStack ? addons.join(", ") : "",
      data.coachingTopic
        ? data.coachingTopic + " / " + data.coachingDuration + " min"
        : "",
    ]
      .filter(Boolean)
      .join("\n");
    // Environment keys are not delivery confirmation. No adapter is configured in this project.
    // Never acknowledge delivery until a real provider dispatch has succeeded.
    return NextResponse.json(
      {
        success: false,
        status: "PROVIDER_PENDING_CONFIG",
        message:
          "Direct delivery is not enabled. Continue through your email app.",
        directMailto:
          "mailto:hello@syahmiaof.my?subject=" +
          encodeURIComponent("Studio Inquiry: " + data.name) +
          "&body=" +
          encodeURIComponent(
            "Name: " +
              data.name +
              "\nContact: " +
              data.contact +
              "\nService: " +
              data.service +
              "\n" +
              context +
              "\n\n" +
              data.message,
          ),
      },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return NextResponse.json(
      { success: false, error: "Unable to process the inquiry." },
      { status: 500 },
    );
  }
}
