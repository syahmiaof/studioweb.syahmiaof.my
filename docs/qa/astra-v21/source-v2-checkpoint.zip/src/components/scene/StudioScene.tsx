"use client";
import { useEffect, useRef, type ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { gsap, useGSAP } from "@/lib/motion/gsapSetup";
import { responsiveMotion } from "@/lib/motion/responsiveMotion";
import type { Locale } from "@/lib/types";

export const localPath = (locale: Locale, path: string) =>
  locale === "en" ? `/en${path === "/" ? "" : path}` : path;
export const copy = (locale: Locale, ms: string, en: string) =>
  locale === "ms" ? ms : en;

export function StudioPage({
  locale,
  children,
}: {
  locale: Locale;
  children: ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);
  useGSAP(
    () => {
      const disposeEntrance = responsiveMotion(
        "(prefers-reduced-motion: no-preference)",
        () => {
          const select = gsap.utils.selector(root);
          const tl = gsap.timeline({
            defaults: { ease: "power3.out", duration: 0.8 },
          });
          const art = select(".scene-art"),
            lines = select(".display-line"),
            foreground = select(".scene-character"),
            controls = select(".scene-intro, .scene-actions, .console");
          if (art.length)
            tl.from(art, { x: 24, scale: 1.025, opacity: 0.45 }, 0);
          if (lines.length)
            tl.from(
              lines,
              { yPercent: 35, clipPath: "inset(0 0 100% 0)", stagger: 0.085 },
              0.05,
            );
          if (foreground.length)
            tl.from(foreground, { y: 28, opacity: 0, duration: 1 }, 0.12);
          if (controls.length)
            tl.from(
              controls,
              { y: 16, opacity: 0, stagger: 0.07, duration: 0.65 },
              0.26,
            );
          select("[data-reveal]").forEach((section: HTMLElement) => {
            gsap.from(section, {
              y: 36,
              opacity: 0.25,
              duration: 0.85,
              scrollTrigger: {
                trigger: section,
                start: "top 94%",
                toggleActions: "play none none reverse",
              },
            });
          });
        },
      );
      const disposeDepth = responsiveMotion(
        "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
        () => {
          root.current
            ?.querySelectorAll<HTMLElement>("[data-depth]")
            .forEach((el) => {
              gsap.to(el, {
                y: Number(el.dataset.depth),
                ease: "none",
                scrollTrigger: {
                  trigger: el.closest(".studio-scene"),
                  start: "top top",
                  end: "bottom top",
                  scrub: 0.5,
                },
              });
            });
        },
      );
      return () => {
        disposeEntrance();
        disposeDepth();
      };
    },
    { scope: root, dependencies: [locale], revertOnUpdate: true },
  );
  return (
    <div className="studio-page" data-locale={locale} ref={root}>
      <Header locale={locale} />
      <main id="main-content">{children}</main>
      <Footer locale={locale} />
    </div>
  );
}
export function DisplayTitle({
  lines,
  accent = 1,
}: {
  lines: string[];
  accent?: number;
}) {
  return (
    <h1 className="display-title">
      {lines.map((line, i) => (
        <span
          key={line}
          className={`display-line ${i === accent ? "accent-line" : ""}`}
        >
          {line}
        </span>
      ))}
    </h1>
  );
}
export function SceneLabel({
  number,
  children,
}: {
  number: string;
  children: ReactNode;
}) {
  return (
    <div className="scene-label">
      <span>[</span> {number} / {children} <span>]</span>
    </div>
  );
}
export function ActionLink({
  href,
  children,
  secondary = false,
  blue = false,
}: {
  href: string;
  children: ReactNode;
  secondary?: boolean;
  blue?: boolean;
}) {
  return (
    <Link
      href={href}
      className={`studio-button ${secondary ? "button-secondary" : ""} ${blue ? "button-blue" : ""}`}
    >
      {children}
      <ArrowRight size={22} aria-hidden="true" />
    </Link>
  );
}
const assets = {
  hero: ["07_hero_seated_character", 1031, 1299],
  builder: ["02_character_builder_laptop", 731, 1473],
  creator: ["03_character_creator_laptop", 908, 1408],
  consultant: ["04_character_consultant_laptop", 487, 1475],
  pointing: ["05_character_pointing_throw", 1100, 1301],
  laptop: ["06_laptop_closed_floating", 839, 831],
} as const;
export function Character({
  kind,
  className = "",
  priority = true,
}: {
  kind: keyof typeof assets;
  className?: string;
  priority?: boolean;
}) {
  const [file, width, height] = assets[kind];
  return (
    <div className={`character character-${kind} ${className}`}>
      <Image
        src={`/assets/optimized/${file}.webp`}
        alt=""
        width={width}
        height={height}
        sizes="(max-width: 767px) 95vw, (max-width: 1023px) 60vw, 58vw"
        priority={priority}
        className="character-image"
      />
    </div>
  );
}
export function Architecture({
  variant,
  word,
}: {
  variant: string;
  word?: string;
}) {
  return (
    <div
      className={`scene-art architecture architecture-${variant}`}
      aria-hidden="true"
    >
      <div className="architectural-ribbon ribbon-cobalt" />
      <div className="architectural-ribbon ribbon-acid" />
      <div className="beam beam-one" />
      <div className="beam beam-two" />
      {word && (
        <div className="monument" data-depth="42">
          <span className="monument-side">{word}</span>
          <span className="monument-face">{word}</span>
        </div>
      )}
      <div className="concrete-platform platform-back" />
      <div className="concrete-platform platform-front" />
      <svg className="architecture-arrow" viewBox="0 0 600 400">
        <path
          d="M10 375 480 85 326 110 310 58 590 10 515 290 460 270 495 140 32 400Z"
          fill="currentColor"
        />
      </svg>
      {variant === "home" && <div className="home-terrace" />}
      <div className="scene-ground" />
    </div>
  );
}
