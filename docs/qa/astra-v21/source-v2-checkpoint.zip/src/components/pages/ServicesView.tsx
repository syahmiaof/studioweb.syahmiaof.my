"use client";
import { Monitor, Database } from "lucide-react";
import type { Locale } from "@/lib/types";
import { SERVICES_DATA } from "@/content/services";
import { PRICING_PACKAGES, formatMYR } from "@/lib/pricing/calculator";
import {
  StudioPage,
  DisplayTitle,
  SceneLabel,
  ActionLink,
  Architecture,
  Character,
  copy,
  localPath,
} from "@/components/scene/StudioScene";
export function ServicesView({ locale }: { locale: Locale }) {
  const c = (ms: string, en: string) => copy(locale, ms, en),
    p = (s: string) => localPath(locale, s);
  return (
    <StudioPage locale={locale}>
      <section className="studio-scene scene-light services-scene">
        <Architecture variant="services" />
        <div className="scene-character builder-person">
          <Character kind="builder" />
        </div>
        <div className="services-copy">
          <SceneLabel number="02">{c("SERVIS", "SERVICES")}</SceneLabel>
          <DisplayTitle
            lines={
              locale === "ms"
                ? ["BINA IDEA.", "LANCAR WEB."]
                : ["BUILD IDEAS.", "LAUNCH WEB."]
            }
          />
          <p className="scene-intro">
            {c(
              "Dari laman promosi ke sistem lengkap — dibina mengikut keperluan anda.",
              "From landing pages to complete systems — built around your needs.",
            )}
          </p>
          <div className="service-panels scene-actions">
            {[0, 1].map((i) => (
              <article
                className={"service-panel " + (i ? "service-blue" : "")}
                key={i}
              >
                <div className="service-panel-heading">
                  <div>
                    <span className="service-number">0{i + 1}/</span>
                    <h2>
                      {i
                        ? c("SISTEM FULL-STACK", "FULL-STACK SYSTEMS")
                        : "WEBSITE FRONTEND"}
                    </h2>
                  </div>
                  {i ? <Database /> : <Monitor />}
                </div>
                <span>{c("Bermula", "From")}</span>
                <strong className="service-price">
                  {formatMYR(PRICING_PACKAGES[i ? 3 : 0].basePrice)}
                </strong>
                <p>
                  {i
                    ? "Login · Database · Dashboard"
                    : "Landing Page · Business Website · Premium"}
                </p>
                <ActionLink
                  href={p(i ? "/hubungi?service=full-stack" : "/harga")}
                  blue={!!i}
                >
                  {i
                    ? c("Bincang Projek", "Discuss a Project")
                    : c("Lihat Pakej", "View Packages")}
                </ActionLink>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="service-details">
        {SERVICES_DATA.map((service) => (
          <article key={service.id} data-reveal>
            <h2>{service.title[locale]}</h2>
            <p>{service.description[locale]}</p>
            <h3>{c("Apa yang diserahkan", "What you receive")}</h3>
            <ul>
              {service.deliverables[locale].map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <details>
              <summary>{c("Skop & batasan", "Scope & boundaries")}</summary>
              <ul>
                {service.boundaries[locale].map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </details>
          </article>
        ))}
      </section>
    </StudioPage>
  );
}
