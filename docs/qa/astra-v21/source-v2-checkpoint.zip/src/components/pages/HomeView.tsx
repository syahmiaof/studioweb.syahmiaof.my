"use client";
import Image from "next/image";
import type { Locale } from "@/lib/types";
import { PRICING_PACKAGES, formatMYR } from "@/lib/pricing/calculator";
import { PROJECTS } from "@/content/projects";
import {
  StudioPage,
  DisplayTitle,
  ActionLink,
  Architecture,
  Character,
  copy,
  localPath,
} from "@/components/scene/StudioScene";
export function HomeView({ locale }: { locale: Locale }) {
  const c = (ms: string, en: string) => copy(locale, ms, en),
    p = (s: string) => localPath(locale, s);
  return (
    <StudioPage locale={locale}>
      <section className="studio-scene home-scene">
        <Architecture variant="home" word="SYA" />
        <div className="hero-copy">
          <div className="home-categories">
            [ {c("PEMBANGUNAN WEBSITE", "WEBSITE DEVELOPMENT")} ]{" "}
            <span>[ COACHING 1:1 ]</span>
          </div>
          <DisplayTitle
            lines={
              locale === "ms"
                ? ["WEB YANG", "BUKAN BIASA."]
                : ["ANYTHING BUT", "ORDINARY."]
            }
          />
          <p className="scene-intro">
            {c(
              "Saya bina pengalaman digital yang hidup — pantas, interaktif dan berimpak.",
              "I build digital experiences that feel alive — fast, interactive and impactful.",
            )}
          </p>
          <div className="scene-actions">
            <ActionLink href={p("/portfolio")}>
              {c("Lihat Portfolio", "View Portfolio")}
            </ActionLink>
            <ActionLink href={p("/hubungi")} secondary>
              {c("Mulakan Projek", "Start a Project")}
            </ActionLink>
          </div>
        </div>
        <div className="scene-character hero-person">
          <Character kind="hero" />
        </div>
        <div className="architecture-caption" aria-hidden="true">
          IDEA
          <br />
          CODE
          <br />
          EXPERIENCE
        </div>
        <a
          href="#services-story"
          className="scroll-cue"
          aria-label={c("Terokai servis", "Explore services")}
        >
          ↓
        </a>
      </section>
      <section className="story-section story-services" id="services-story">
        <div className="story-heading" data-reveal>
          <span className="chapter-line">
            01 / {c("APA KITA BINA", "WHAT WE BUILD")}
          </span>
          <h2>
            {c("SERVIS", "SERVICES")}
            <br />
            <span>{c("WEB & SISTEM.", "WEB & SYSTEMS.")}</span>
          </h2>
          <p>
            {c(
              "Dari laman promosi ke sistem lengkap. Dibina mengikut keperluan anda.",
              "From a focused landing page to a complete system. Built around your needs.",
            )}
          </p>
          <ActionLink href={p("/servis")}>
            {c("Terokai Servis", "Explore Services")}
          </ActionLink>
        </div>
        <div className="service-index" data-reveal>
          {[PRICING_PACKAGES[0], PRICING_PACKAGES[3]].map((item, i) => (
            <a
              href={p(i ? "/hubungi?service=full-stack" : "/harga")}
              key={item.id}
            >
              <span>0{i + 1}</span>
              <h3>{i ? "CUSTOM FULL-STACK" : "WEBSITE FRONTEND"}</h3>
              <p>{item.scopeSummary[locale]}</p>
              <strong>
                {c("Dari ", "From ")}
                {formatMYR(item.basePrice)} ↗
              </strong>
            </a>
          ))}
        </div>
      </section>
      <section className="story-section story-work">
        <div className="story-heading" data-reveal>
          <span className="chapter-line">
            02 / {c("PROJEK PILIHAN", "SELECTED WORK")}
          </span>
          <h2>
            {c("IDEA JADI", "IDEAS MADE")}
            <br />
            <span>{c("REALITI.", "REAL.")}</span>
          </h2>
          <ActionLink href={p("/portfolio")} secondary>
            {c("Semua Projek", "All Projects")}
          </ActionLink>
        </div>
        <div className="work-strip" data-reveal>
          {PROJECTS.map((project) => (
            <a href={p("/portfolio") + "#" + project.slug} key={project.id}>
              <Image
                src={project.image
                  .replace("/projects/", "/optimized/")
                  .replace(".png", ".webp")}
                alt={project.title}
                width={600}
                height={375}
                sizes="(max-width: 767px) 90vw, 25vw"
              />
              <span>{project.title} ↗</span>
              <small>
                {locale === "ms" ? "Visual konsep" : "Concept visual"}
              </small>
            </a>
          ))}
        </div>
      </section>
      <section className="story-section story-price">
        <div data-reveal>
          <span className="chapter-line">03 / PRICING STUDIO</span>
          <h2>
            {c("BINA IKUT", "BUILT FOR")}
            <br />
            {c("BAJET.", "YOUR BUDGET.")}
          </h2>
        </div>
        <div className="story-price-content" data-reveal>
          <p>
            {c(
              "Pilih pakej. Tambah fungsi. Lihat anggaran sebelum kita mula berbincang.",
              "Choose a package. Add features. See your estimate before we start talking.",
            )}
          </p>
          <div className="price-ladder">
            {PRICING_PACKAGES.filter((p) => !p.isFullStack).map((pkg) => (
              <div key={pkg.id}>
                <span>{pkg.name[locale].replace("Frontend ", "")}</span>
                <strong>{formatMYR(pkg.basePrice)}</strong>
              </div>
            ))}
          </div>
          <ActionLink href={p("/harga")}>
            {c("Kira Anggaran Projek", "Estimate Your Project")}
          </ActionLink>
        </div>
      </section>
      <section className="story-section story-coaching">
        <div className="teaser-person" data-reveal>
          <Character kind="creator" priority={false} />
          <span aria-hidden="true">1:1</span>
        </div>
        <div className="story-heading" data-reveal>
          <span className="chapter-line">04 / COACHING</span>
          <h2>
            {c("BELAJAR. BINA.", "LEARN. BUILD.")}
            <br />
            <span>DEPLOY.</span>
          </h2>
          <p>
            {c(
              "Bimbingan hands-on. Dari asas web hingga projek sebenar, ikut tahap dan matlamat anda.",
              "Hands-on guidance. From web fundamentals to real projects, at your level and towards your goals.",
            )}
          </p>
          <ActionLink href={p("/coaching")}>
            {c("Terokai Coaching 1:1", "Explore 1:1 Coaching")}
          </ActionLink>
        </div>
      </section>
      <section className="story-section story-about">
        <div data-reveal>
          <span className="chapter-line">
            05 / {c("DI SEBALIK STUDIO", "BEHIND THE STUDIO")}
          </span>
          <h2>
            SYAHMI
            <br />
            AOF.
          </h2>
        </div>
        <div data-reveal>
          <p className="story-about-lead">
            {c(
              "Pembangun web. Pelajar IT (Cloud Computing). Pembina idea digital.",
              "Web developer. IT (Cloud Computing) student. Builder of digital ideas.",
            )}
          </p>
          <p>TVETMARA Besut · Freelance Web Development · DFK INC</p>
          <ActionLink href={p("/tentang")} secondary>
            {c("Kenali Saya", "Meet the Developer")}
          </ActionLink>
        </div>
      </section>
      <section className="story-finale" data-reveal>
        <h2>
          {c("IDEA KAU.", "YOUR IDEA.")}
          <br />
          <span>{c("KITA BINA.", "LET’S BUILD.")}</span>
        </h2>
        <ActionLink href={p("/hubungi")}>
          {c("Bincang Projek", "Discuss a Project")}
        </ActionLink>
      </section>
    </StudioPage>
  );
}
