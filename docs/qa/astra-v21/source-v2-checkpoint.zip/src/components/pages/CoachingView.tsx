"use client";
import { Suspense, useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { COACHING_TOPICS } from "@/content/coaching";
import type { Locale } from "@/lib/types";
import {
  StudioPage,
  DisplayTitle,
  SceneLabel,
  ActionLink,
  Architecture,
  Character,
  copy,
  localPath,
} from "@/components/scene/StudioScene";
function Coaching({ locale }: { locale: Locale }) {
  const params = useSearchParams(),
    pathname = usePathname();
  const [topic, setTopic] = useState(() =>
    COACHING_TOPICS.some((t) => t.id === params.get("topic"))
      ? params.get("topic")!
      : "react-next",
  );
  const [duration, setDuration] = useState(
    params.get("duration") === "90" ? "90" : "60",
  );
  const selected = COACHING_TOPICS.find((t) => t.id === topic)!;
  const c = (ms: string, en: string) => copy(locale, ms, en);
  const select = (nextTopic: string, nextDuration: string) => {
    setTopic(nextTopic);
    setDuration(nextDuration);
    window.history.replaceState(
      null,
      "",
      pathname +
        "?" +
        new URLSearchParams({ topic: nextTopic, duration: nextDuration }),
    );
  };
  const names = [
    c("Asas Web", "Web Basics"),
    "React / Next.js",
    c("Mentor Projek", "Project Mentor"),
  ];
  return (
    <StudioPage locale={locale}>
      <section className="studio-scene coaching-scene">
        <Architecture variant="coaching" word="05" />
        <div className="scene-character creator-person">
          <Character kind="creator" />
        </div>
        <div className="coaching-copy">
          <SceneLabel number="05">COACHING 1:1</SceneLabel>
          <DisplayTitle
            lines={[c("BELAJAR.", "LEARN."), c("BINA.", "BUILD."), "DEPLOY."]}
          />
          <p className="scene-intro">
            {c(
              "Bimbingan hands-on, daripada asas web hingga projek sebenar.",
              "Hands-on guidance, from web fundamentals to real projects.",
            )}
          </p>
          <div className="console coaching-console">
            <fieldset>
              <legend>1. {c("PILIH TOPIK", "CHOOSE A TOPIC")}</legend>
              <div className="topic-options">
                {COACHING_TOPICS.map((item, i) => (
                  <label
                    key={item.id}
                    className={
                      "choice-option " + (topic === item.id ? "selected" : "")
                    }
                  >
                    <input
                      type="radio"
                      name="topic"
                      checked={topic === item.id}
                      onChange={() => select(item.id, duration)}
                    />
                    <span>{names[i]}</span>
                  </label>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend>2. {c("DURASI SESI", "SESSION DURATION")}</legend>
              <div className="duration-options">
                {["60", "90"].map((value) => (
                  <label
                    key={value}
                    className={
                      "choice-option " + (duration === value ? "selected" : "")
                    }
                  >
                    <input
                      type="radio"
                      name="duration"
                      checked={duration === value}
                      onChange={() => select(topic, value)}
                    />
                    <span>{value} min</span>
                  </label>
                ))}
              </div>
            </fieldset>
            <ActionLink
              href={
                localPath(locale, "/hubungi") +
                "?" +
                new URLSearchParams({ service: "coaching", topic, duration })
              }
            >
              {c("Tanya Slot Coaching", "Ask About Coaching")}
            </ActionLink>
            <p>
              Online · 1:1 · {c("Bahasa Melayu", "Malay")}
              <br />
              <span>
                {c(
                  "Harga dan jadual disahkan selepas perbincangan.",
                  "Price and schedule confirmed after discussion.",
                )}
              </span>
            </p>
          </div>
        </div>
      </section>
      <section className="coaching-detail">
        <div>
          <span className="chapter-line">
            {c("APA YANG KITA PELAJARI", "WHAT WE WILL EXPLORE")}
          </span>
          <h2>{selected.title[locale]}</h2>
          <p>{selected.description[locale]}</p>
        </div>
        <ul>
          {selected.points[locale].map((point) => (
            <li key={point}>{point}</li>
          ))}
        </ul>
      </section>
    </StudioPage>
  );
}
export function CoachingView({ locale }: { locale: Locale }) {
  return (
    <Suspense fallback={<div className="route-loading">Coaching 1:1</div>}>
      <Coaching locale={locale} />
    </Suspense>
  );
}
