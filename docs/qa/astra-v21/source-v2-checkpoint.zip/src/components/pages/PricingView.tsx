"use client";
import { Suspense, useRef, useState } from "react";
import { useSearchParams, usePathname } from "next/navigation";
import { Globe, Play, Code2 } from "lucide-react";
import type { Locale } from "@/lib/types";
import {
  PRICING_PACKAGES,
  PRICING_ADDONS,
  calculateFrontendEstimate,
  formatMYR,
} from "@/lib/pricing/calculator";
import { gsap, useGSAP } from "@/lib/motion/gsapSetup";
import { responsiveMotion } from "@/lib/motion/responsiveMotion";
import {
  StudioPage,
  DisplayTitle,
  SceneLabel,
  ActionLink,
  Architecture,
  copy,
  localPath,
} from "@/components/scene/StudioScene";
function Configurator({ locale }: { locale: Locale }) {
  const params = useSearchParams(),
    pathname = usePathname();
  const [selected, setSelected] = useState(() =>
    PRICING_PACKAGES.some(
      (p) => p.id === params.get("package") && !p.isFullStack,
    )
      ? params.get("package")!
      : "business",
  );
  const [addons, setAddons] = useState<string[]>(() =>
    Array.from(new Set((params.get("addons") || "").split(","))).filter((id) =>
      PRICING_ADDONS.some((a) => a.id === id),
    ),
  );
  const total = calculateFrontendEstimate(selected, addons).total;
  const number = useRef<HTMLSpanElement>(null),
    previous = useRef(total);
  const c = (ms: string, en: string) => copy(locale, ms, en),
    p = (s: string) => localPath(locale, s);
  const select = (pkg: string, next: string[]) => {
    setSelected(pkg);
    setAddons(next);
    const query = new URLSearchParams({ package: pkg, addons: next.join(",") });
    window.history.replaceState(null, "", pathname + "?" + query.toString());
  };
  useGSAP(
    () => {
      if (number.current) number.current.textContent = formatMYR(total);
      const dispose = responsiveMotion(
        "(prefers-reduced-motion: no-preference)",
        () => {
          const value = { amount: previous.current };
          gsap.to(value, {
            amount: total,
            duration: 0.45,
            ease: "power2.out",
            onUpdate: () => {
              if (number.current)
                number.current.textContent = formatMYR(
                  Math.round(value.amount),
                );
            },
          });
          return () => {
            if (number.current) number.current.textContent = formatMYR(total);
          };
        },
      );
      previous.current = total;
      return dispose;
    },
    { dependencies: [total], revertOnUpdate: true },
  );
  const quote =
    p("/hubungi") +
    "?" +
    new URLSearchParams({
      service: "website-ui",
      package: selected,
      addons: addons.join(","),
      estimate: String(total),
    });
  return (
    <StudioPage locale={locale}>
      <section className="studio-scene scene-light pricing-scene">
        <Architecture variant="pricing" />
        <div className="pricing-copy">
          <SceneLabel number="04">{c("HARGA", "PRICING")}</SceneLabel>
          <DisplayTitle
            lines={
              locale === "ms"
                ? ["BINA IKUT", "BAJET."]
                : ["BUILD TO", "YOUR BUDGET."]
            }
          />
          <p className="scene-intro">
            {c(
              "Pilih pakej, tambah fungsi dan lihat anggaran projek anda.",
              "Choose your package, add features and see your project estimate.",
            )}
          </p>
        </div>
        <div className="pricing-monument" aria-hidden="true" />
        <div className="pricing-console-wrap">
          <div className="console pricing-console">
            <h2>
              {c("KIRA HARGA", "PRICE YOUR")} <span>WEBSITE</span>
            </h2>
            <fieldset>
              <legend>1. {c("PILIH PAKEJ", "CHOOSE A PACKAGE")}</legend>
              <div className="package-options">
                {PRICING_PACKAGES.filter((pkg) => !pkg.isFullStack).map(
                  (pkg) => (
                    <label
                      key={pkg.id}
                      className={
                        "package-option " +
                        (selected === pkg.id ? "selected" : "")
                      }
                    >
                      <input
                        type="radio"
                        name="package"
                        value={pkg.id}
                        checked={selected === pkg.id}
                        onChange={() => select(pkg.id, addons)}
                      />
                      <span>
                        <span>{pkg.name[locale].replace("Frontend ", "")}</span>
                        <strong>{formatMYR(pkg.basePrice)}</strong>
                      </span>
                    </label>
                  ),
                )}
              </div>
            </fieldset>
            <fieldset>
              <legend>
                2. {c("TAMBAH FUNGSI (ADD-ON)", "ADD FEATURES (ADD-ON)")}
              </legend>
              <div className="addon-options">
                {PRICING_ADDONS.map((addon, i) => (
                  <label className="addon-option" key={addon.id}>
                    {i ? <Globe /> : <Play />}
                    <span>
                      {i
                        ? c("Bahasa Kedua", "Second Language")
                        : c("Animasi Lanjutan", "Advanced Animation")}
                    </span>
                    <strong>+{formatMYR(addon.price)}</strong>
                    <input
                      type="checkbox"
                      checked={addons.includes(addon.id)}
                      onChange={() =>
                        select(
                          selected,
                          addons.includes(addon.id)
                            ? addons.filter((a) => a !== addon.id)
                            : [...addons, addon.id],
                        )
                      }
                    />
                    <span className="switch" aria-hidden="true" />
                  </label>
                ))}
              </div>
            </fieldset>
            <div className="estimate-panel">
              <div>
                <h3>{c("ANGGARAN PROJEK", "PROJECT ESTIMATE")}</h3>
                <span
                  className="estimate-number"
                  ref={number}
                  aria-hidden="true"
                >
                  {formatMYR(total)}
                </span>
                <output
                  className="sr-only"
                  aria-live="polite"
                  data-testid="estimate"
                >
                  {formatMYR(total)}
                </output>
              </div>
              <div>
                <ActionLink href={quote}>
                  {c("Dapatkan Sebut Harga", "Request a Quote")}
                </ActionLink>
                <p>
                  {c(
                    "Anggaran sahaja. Domain, hosting dan skop tambahan berasingan.",
                    "Estimate only. Domain, hosting and additional scope are separate.",
                  )}
                </p>
              </div>
            </div>
          </div>
          <div className="custom-system">
            <Code2 />
            <div>
              <span>{c("Sistem custom?", "Custom system?")}</span>
              <strong>
                {c("Dari ", "From ")}
                {formatMYR(PRICING_PACKAGES[3].basePrice)}
              </strong>
            </div>
            <ActionLink
              blue
              href={p("/hubungi?service=full-stack&package=custom-system")}
            >
              {c("Bincang Projek", "Discuss a Project")}
            </ActionLink>
          </div>
        </div>
      </section>
      <section className="package-detail">
        <h2>
          {PRICING_PACKAGES.find((pkg) => pkg.id === selected)?.name[locale]}
        </h2>
        <p>
          {
            PRICING_PACKAGES.find((pkg) => pkg.id === selected)?.scopeSummary[
              locale
            ]
          }
        </p>
        <ul>
          {PRICING_PACKAGES.find((pkg) => pkg.id === selected)?.deliverables[
            locale
          ].map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
    </StudioPage>
  );
}
export function PricingView({ locale }: { locale: Locale }) {
  return (
    <Suspense fallback={<div className="route-loading">Pricing Studio</div>}>
      <Configurator locale={locale} />
    </Suspense>
  );
}
