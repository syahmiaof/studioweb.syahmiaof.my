"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { Menu, X } from "lucide-react";
import { getTranslations } from "@/i18n";
import type { Locale } from "@/lib/types";
function HeaderBar({ locale }: { locale: Locale }) {
  const pathname = usePathname();
  const params = useSearchParams();
  const t = getTranslations(locale);
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  const routes = [
    "",
    "servis",
    "portfolio",
    "harga",
    "coaching",
    "tentang",
    "hubungi",
  ];
  const labels = [
    t.nav.home,
    t.nav.services,
    t.nav.portfolio,
    t.nav.pricing,
    t.nav.coaching,
    t.nav.about,
    t.nav.contact,
  ];
  const prefix = locale === "en" ? "/en" : "";
  const alternate =
    locale === "ms"
      ? "/en" + (pathname === "/" ? "" : pathname)
      : pathname.replace(/^\/en(?=\/|$)/, "") || "/";
  useEffect(() => {
    setOpen(false);
  }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const escape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggle.current?.focus();
      }
    };
    document.addEventListener("keydown", escape);
    return () => document.removeEventListener("keydown", escape);
  }, [open]);
  return (
    <header className="studio-header">
      <a className="skip-link" href="#main-content">
        {locale === "ms" ? "Terus ke kandungan" : "Skip to content"}
      </a>
      <Link
        className="studio-brand"
        href={prefix || "/"}
        aria-label="SYAHMIAOF Studio"
      >
        SYAHMIAOF<span className="brand-dot">.</span>
      </Link>
      <nav
        aria-label={locale === "ms" ? "Navigasi utama" : "Main navigation"}
        id="studio-navigation"
        className={"studio-nav " + (open ? "is-open" : "")}
      >
        {routes.map((route, i) => {
          const href = route ? prefix + "/" + route : prefix || "/";
          return (
            <Link
              key={route}
              href={href}
              aria-current={pathname === href ? "page" : undefined}
              onClick={() => setOpen(false)}
            >
              {labels[i]}
            </Link>
          );
        })}
      </nav>
      <div className="header-actions">
        <Link
          className="language-switch"
          href={alternate + (params.toString() ? "?" + params.toString() : "")}
          aria-label={locale === "ms" ? "EN" : "BM"}
        >
          <span className={locale === "ms" ? "current-language" : ""}>BM</span>
          <span>/</span>
          <span className={locale === "en" ? "current-language" : ""}>EN</span>
        </Link>
        <button
          className="menu-toggle"
          ref={toggle}
          aria-label={
            locale === "ms" ? "Buka menu navigasi" : "Toggle navigation menu"
          }
          aria-expanded={open}
          aria-controls="studio-navigation"
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>
    </header>
  );
}
export function Header({ locale }: { locale: Locale }) {
  return (
    <Suspense
      fallback={
        <header className="studio-header">
          <span className="studio-brand">SYAHMIAOF.</span>
        </header>
      }
    >
      <HeaderBar locale={locale} />
    </Suspense>
  );
}
